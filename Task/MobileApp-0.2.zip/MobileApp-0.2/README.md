MobileApp
=========

Test Spring MVC REST application based on CNVR
