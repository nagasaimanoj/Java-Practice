public class DataClass {
    int a = 9;
}