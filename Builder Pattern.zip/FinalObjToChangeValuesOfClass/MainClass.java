public class MainClass {
    public static void main(String[] args) {
        final DataClass dc = new DataClass();
        dc.a = 999;
        System.out.println(dc.a);
    }
}