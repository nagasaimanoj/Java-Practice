public class Class1 {
    public static void main(String[] args) {
        System.out.println("this is working");
    }

    static {
        System.out.println("this is also working");
    }
}