public class BobBuilder {
    public static void main(String... a) {
        new Data().setName("Manoj").setAge(23).setHeight(5.8).setPhone(99999).setHasEyeSighData(false).details();
        new Data().setName("Dhivya").setAge(21).setHeight(5.4).setPhone(88888).setHasEyeSighData(true).details();
        new Data().setName("Aruna").setAge(24).setHeight(5.3).setPhone(77777).setHasEyeSighData(true).details();
    }
}