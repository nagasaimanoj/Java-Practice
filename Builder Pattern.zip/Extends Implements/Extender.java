public class Extender {
    public static void print() {
        System.out.println("this is some text from Extender");
    }
}