package Comedy;

public class Comedy1 {
    static void check() {
        System.out.println("This is working");
    }
}