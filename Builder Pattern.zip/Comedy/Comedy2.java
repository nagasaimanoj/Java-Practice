package Comedy;

public class Comedy2 {
    public static void main(String[] args) {
        Comedy2 c2 = new Comedy2();
        c2.check();
    }

    void check() {
        Comedy1.check();
    }
}