class Inher{
    public static void main(String args[]){
        System.out.println("hi there");
    }
}