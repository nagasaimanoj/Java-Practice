public interface PhoneDesign {
    void functionality();
}