public class Data {
    public final static String iPhone = "iPhone 6";
    public final static String samsung = "Galaxy J2";
    public final static String sony = "Sony Xperia";
}