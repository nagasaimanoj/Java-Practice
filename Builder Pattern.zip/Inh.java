/*
public class Inh extends Easy{
	static int a = 10;
	public static void main(String args[]){
		printf("Hello There");
		printf2("Hello There");
		printf2(""+super.a);
		printf2(""+this.a);
		printf2(""+super.a);
		}
	}
class Easy extends Easy1{
	static int a = 20;
	static void printf(String str){
		System.out.println(str);
	}
}
class Easy1{
	static int a = 30;
	static void printf2(String str){
		System.out.println(str);
	}
}
*/