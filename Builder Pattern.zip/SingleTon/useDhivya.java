class useDhivya {
    public static void main(String[] args) {
        singleTonClass.getObject().test();
    }
}