class Counter{  
     int  count=1;
  
 final Counter(){  
int count=10;
System.out.println(count);  
}  
  
public static void main(String args[]){  
  
Counter c1=new Counter();  
 }  
}  