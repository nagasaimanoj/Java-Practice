class Baskar
{
    public static void main(String args[]) 
    { 
        int a=200;  
        short s; 
        int i = 257; 
        double d = 323.142;
        s = (short)i; 
        System.out.println("i = b " + i + " s = " + s);
        s = (short)d; 
        System.out.println("d = " + d + " s= " + s);
        String str=Integer.toString(a);  
        System.out.println(a+100);
        System.out.println(str+100);  
}}  
    
