class Sa
{
  int a=15;



}
class s extends Sa
{
   int a=20;
   
public static void main(String args[])
{
  Sa s1=new Sa();  
 // int k=super.a;
System.out.println(s1.a);
//System.out.println(this.a);

}

}