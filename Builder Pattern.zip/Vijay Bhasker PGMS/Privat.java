class Pri {
  
  private Pri(){
       
       
   }
 
public static void main(String args[]){ 
   
      Pri s= new Pri();
  }
 
}