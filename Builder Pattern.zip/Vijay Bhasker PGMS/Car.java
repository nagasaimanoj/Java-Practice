class Car{  
    String mod;
    String color;
} 
