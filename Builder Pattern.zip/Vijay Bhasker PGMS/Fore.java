class Fore
{
    
public static void main(String args[]){  
String s1="java string split method by javatpoint";  
String[] words=s1.split(" "); 
for(int i=5;i>1;i--)
{
   String a[]=words;
   
System.out.println(a[i]);
//for(String w:str){  
//System.out.println(w);  

}}  }