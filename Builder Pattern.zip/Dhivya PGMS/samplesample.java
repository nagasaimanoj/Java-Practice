public class samplesample {
    public static void main(String... x) {
        System.out.println("this is working");
    }
}