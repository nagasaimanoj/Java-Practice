public class Sample1 {
    static void runThis() {
        System.out.println("This is working");
    }
}