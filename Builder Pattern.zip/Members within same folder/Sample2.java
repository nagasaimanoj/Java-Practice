public class Sample2 {
    public static void main(String[] args) {
        Sample1.runThis();
    }
}