import java.util.*;
class alist
{
    public static void main(String args[])
    {
        ArrayList<String> a= new ArrayList<String>();
        a.add("nnaga");
        a.add("captain");
        a.forEach(System.out::println);
       }
}