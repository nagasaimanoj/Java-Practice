public class SomeOtherClass {
    void runThis() throws Exception{
        throw new Exception("this is an exception");
    }
}