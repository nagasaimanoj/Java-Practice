public class Child extends Parent {
    void identify() {
        System.out.println("This is from child class");
    }
}