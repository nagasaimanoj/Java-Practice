public class Parent {
    void identify() {
        System.out.println("This is from parent class");
    }

    void identify2() {
        System.out.println("This is from parent class");
    }
}