public class JustClass {
    public static void main(String[] args) {
        Parent c = new Child();
        c.identify();
        c.identify2();
    }
}