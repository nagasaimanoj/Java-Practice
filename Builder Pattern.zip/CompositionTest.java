/*import java.util.*;

class CompositionTest {
	public static void main(String[] args) {
		Student student1 = new Student(1, "Student1", "Department1");
		Student student2 = new Student(2, "Student2", "Department1");
		Student student3 = new Student(3, "Student3", "Department1");

		List<Student> students = new ArrayList<Student>();
		students.add(student1);
		students.add(student2);
		students.add(student3);

		Department dept = new Department("Department", students);

		List<Student> stu = dept.getStudents();
		for (Student s : stu) {
			System.out.println(s.getRollno() + " " + s.getName() + " " + s.getDepartment());
		}

	}
}
*/