package com.gnsmk;

public class Sum{
	public int add(int x, int y){
		return x+y;
	}
}